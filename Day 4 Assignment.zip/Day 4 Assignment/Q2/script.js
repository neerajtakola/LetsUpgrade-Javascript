function copyContent(){
  const ele=document.getElementById("input2");
  ele.value=document.getElementById("input1").value;
  document.getElementById("input1").value="";
}