function imageSecond(){
  const ele= document.getElementById("img");
  const newUrl="https://upload.wikimedia.org/wikipedia/en/3/30/Java_programming_language_logo.svg";
  ele.src=newUrl;
}

function imageThird(){
  const ele= document.getElementById("img");
  const newUrl="https://coryrylan.com/assets/images/posts/types/javascript-1280x960.png";
  ele.src=newUrl;
}

function imageFirst(){
  const ele= document.getElementById("img");
  const newUrl="https://upload.wikimedia.org/wikipedia/commons/thumb/c/c3/Python-logo-notext.svg/768px-Python-logo-notext.svg.png";
  ele.src=newUrl;
}
