let person=[
  {
    name:"Neeraj",
    age:26,
    country:"India",
    hobbies:[
      "Coding","Eating"
    ]
  },
  {
    name:"Quincy",
    age:43,
    country:"US",
    hobbies:[
      "Eating","Football"
    ]
  },
  {
    name:"Lisa",
    age:32,
    country:"Australia",
    hobbies:[
      "Singing","Dancing"
    ]
  }
];

person.forEach(function (person){
  console.log("Name",person.name);
  console.log("Age",person.age);
  console.log("Country",person.country);
  console.log("Hobbies: ")
  person.hobbies.forEach(function (hobby){
    console.log(hobby);
  });
  console.log("");
});