let person=[
  {
    name:"Neeraj",
    age:26,
    country:"India",
    hobbies:[
      "Coding","Eating"
    ]
  },
  {
    name:"Prashant",
    age:24,
    country:"Australia",
    hobbies:[
      "Gaming","Dancing"
    ]
  },
  {
    name:"Amey",
    age:22,
    country:"India",
    hobbies:[
      "Programming","Sleeping"
    ]
  },
  {
    name:"Quincy",
    age:43,
    country:"India",
    hobbies:[
      "Eating","Football"
    ]
  },
  {
    name:"Lisa",
    age:32,
    country:"Australia",
    hobbies:[
      "Singing","Dancing"
    ]
  }
];

person.forEach(function (person){
  if(person.age<30){
    console.log(person.name);
  }
});

person.forEach(function (person){
  if(person.country=="India"){
    console.log(person.name);
  }
});